package com.nhai.app

import android.content.Context

object Prefs {
    const val DEFAULT_WAKE =
        "ai sunco, ai suncho, ai shuncho, hi sunco, এই শুনছো, এই শুনছ, আই শুনছো, এ আই শুনছো, এআই শুনছো, এই সুনছো"
    const val DEFAULT_MODEL = "claude-sonnet-5-5"

    private fun sp(c: Context) = c.getSharedPreferences("nhai", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("key", "") ?: ""
    fun setApiKey(c: Context, k: String) { sp(c).edit().putString("key", k.trim()).apply() }

    fun model(c: Context): String {
        val m = sp(c).getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        return if (m.isBlank()) DEFAULT_MODEL else m.trim()
    }
    fun setModel(c: Context, m: String) { sp(c).edit().putString("model", m.trim()).apply() }

    fun wakeRaw(c: Context): String {
        val w = sp(c).getString("wake", DEFAULT_WAKE) ?: DEFAULT_WAKE
        return if (w.isBlank()) DEFAULT_WAKE else w
    }
    fun setWake(c: Context, w: String) { sp(c).edit().putString("wake", w.trim()).apply() }

    fun countryCode(c: Context): String {
        val v = sp(c).getString("cc", "880") ?: "880"
        return v.filter { it.isDigit() }.ifEmpty { "880" }
    }
    fun setCountryCode(c: Context, v: String) { sp(c).edit().putString("cc", v.trim()).apply() }

    const val DEFAULT_GEMINI_MODEL = "gemini-flash-latest"

    fun provider(c: Context): String = sp(c).getString("provider", "gemini") ?: "gemini"
    fun setProvider(c: Context, p: String) { sp(c).edit().putString("provider", p).apply() }

    fun geminiKey(c: Context): String = sp(c).getString("gkey", "") ?: ""
    fun setGeminiKey(c: Context, k: String) { sp(c).edit().putString("gkey", k.trim()).apply() }

    fun geminiModel(c: Context): String {
        val m = (sp(c).getString("gmodel", DEFAULT_GEMINI_MODEL) ?: DEFAULT_GEMINI_MODEL).trim().removePrefix("models/")
        return if (m.isBlank()) DEFAULT_GEMINI_MODEL else m
    }
    fun setGeminiModel(c: Context, m: String) { sp(c).edit().putString("gmodel", m.trim()).apply() }

    fun offlineFirst(c: Context): Boolean = sp(c).getBoolean("offlinefirst", false)
    fun setOfflineFirst(c: Context, b: Boolean) { sp(c).edit().putBoolean("offlinefirst", b).apply() }

    fun directCall(c: Context): Boolean = sp(c).getBoolean("direct", false)
    fun setDirectCall(c: Context, b: Boolean) { sp(c).edit().putBoolean("direct", b).apply() }
}
