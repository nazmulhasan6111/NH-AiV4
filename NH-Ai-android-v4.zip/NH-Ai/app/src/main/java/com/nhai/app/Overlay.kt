package com.nhai.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** Onno app-er upor floating orb ar popup panel. */
class Overlay(private val ctx: Context, private val onOrbTap: () -> Unit) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private var orb: OrbView? = null
    private var panel: LinearLayout? = null
    private var panelOrb: OrbView? = null
    private var statusTv: TextView? = null
    private var bodyTv: TextView? = null

    @SuppressLint("ClickableViewAccessibility")
    fun showOrb() {
        if (orb != null || !Settings.canDrawOverlays(ctx)) return
        val size = ctx.dp(58)
        val lp = WindowManager.LayoutParams(
            size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = ctx.dp(6)
        lp.y = ctx.dp(220)
        val v = OrbView(ctx)
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > ctx.dp(6) || abs(dy) > ctx.dp(6)) moved = true
                    if (moved) {
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) { }
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onOrbTap()
            }
            true
        }
        try {
            wm.addView(v, lp)
            orb = v
        } catch (ex: Exception) { }
    }

    fun showPanel(status: String, body: String) {
        if (!Settings.canDrawOverlays(ctx)) return
        if (panel == null) {
            val root = LinearLayout(ctx)
            root.orientation = LinearLayout.VERTICAL
            root.setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(14))
            root.background = neonBg(ctx, C.CYAN, C.PANEL, 22)

            val head = LinearLayout(ctx)
            head.orientation = LinearLayout.HORIZONTAL
            head.gravity = Gravity.CENTER_VERTICAL
            val po = OrbView(ctx)
            head.addView(po, LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)))
            val st = TextView(ctx)
            st.textSize = 13f
            st.setTextColor(C.CYAN)
            st.letterSpacing = 0.2f
            st.typeface = Typeface.DEFAULT_BOLD
            val stLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            stLp.leftMargin = ctx.dp(10)
            head.addView(st, stLp)
            val close = TextView(ctx)
            close.text = "✕"
            close.textSize = 18f
            close.setTextColor(C.MAG)
            close.setPadding(ctx.dp(12), ctx.dp(4), ctx.dp(4), ctx.dp(4))
            close.setOnClickListener { hidePanel() }
            head.addView(close)

            val bd = TextView(ctx)
            bd.textSize = 16f
            bd.setTextColor(C.TEXT)
            bd.setPadding(0, ctx.dp(8), 0, 0)
            root.addView(head)
            root.addView(bd)

            val lp = WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.y = ctx.dp(40)
            lp.horizontalMargin = 0.04f
            try {
                wm.addView(root, lp)
            } catch (ex: Exception) {
                return
            }
            panel = root
            panelOrb = po
            statusTv = st
            bodyTv = bd
        }
        statusTv?.text = status
        bodyTv?.text = body
    }

    fun hidePanel() {
        val p = panel
        if (p != null) {
            try { wm.removeView(p) } catch (ex: Exception) { }
        }
        panel = null
        panelOrb = null
        statusTv = null
        bodyTv = null
    }

    fun setActive(a: Boolean) {
        orb?.active = a
        panelOrb?.active = a
    }

    fun removeAll() {
        hidePanel()
        val o = orb
        if (o != null) {
            try { wm.removeView(o) } catch (ex: Exception) { }
        }
        orb = null
    }
}
