package com.nhai.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Background e chole: "ai sunco" shuney jage, tarpor command shuney kaj kore. */
class AssistantService : Service(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile
        var isRunning = false
        private const val CHANNEL = "nhai_channel"

        // Wake word er variant. Space ar punctuation baad diye match kora hoy.
        private val WAKE = listOf(
            "aisunco", "aisuncho", "aishunco", "aishuncho", "aisunchho", "hisunco", "aysunco", "eisunco", "eisuncho",
            "এইশুনছো", "এইশুনছ", "আইশুনছো", "আইশুনছ", "এইসুনছো", "এইশুনছেন", "আইসুনছো", "এআইশুনছো", "এআইশুনছ"
        )
    }

    private enum class Mode { WAKE, COMMAND }

    private val main = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var overlay: Overlay? = null
    private var mode = Mode.WAKE
    private var running = false
    private var handled = false
    private var busy = false
    private var offlineFailed = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startFg()
        running = true
        isRunning = true
        tts = TextToSpeech(this, this)
        overlay = Overlay(this) { onOrbTapped() }
        overlay?.showOrb()
        listen(Mode.WAKE, 300)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "NH-Ai", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("NH-Ai চালু আছে")
            .setContentText("বলো: \"ai sunco\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- Speech recognition loop ----------
    private fun listen(m: Mode, delayMs: Long) {
        main.postDelayed({ startRecognizer(m) }, delayMs)
    }

    private fun startRecognizer(m: Mode) {
        if (!running) return
        releaseSr()
        mode = m
        handled = false
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            overlay?.showPanel("ERROR", "এই ফোনে speech recognition সার্ভিস নেই। Google অ্যাপ আপডেট করো।")
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(listener)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        val offline = !isOnline() || (Prefs.offlineFirst(this) && !offlineFailed)
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline)
        sr = r
        try {
            r.startListening(i)
        } catch (e: Exception) {
            listen(m, 1500)
        }
        overlay?.setActive(m == Mode.COMMAND)
    }

    private fun releaseSr() {
        val r = sr
        sr = null
        if (r != null) {
            try { r.cancel() } catch (e: Exception) { }
            try { r.destroy() } catch (e: Exception) { }
        }
    }

    private fun norm(s: String): String =
        s.lowercase(Locale.ROOT).filterNot { it.isWhitespace() || it in ".,!?-'\"।" }

    private fun wakeList(): List<String> {
        val custom = Prefs.wakeRaw(this).split(',', '\n').map { norm(it) }.filter { it.length >= 3 }
        return custom + WAKE
    }

    private fun isWake(list: List<String>?): Boolean {
        if (list == null) return false
        for (s in list) {
            val n = norm(s)
            if (wakeList().any { n.contains(it) }) return true
        }
        return false
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (!running || handled || busy) return
            if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) AppLog.add("recognizer error $error")
            if (error == 12 || error == 13) {
                offlineFailed = true
                AppLog.add("speech language/offline pack unavailable ($error)")
                if (!isOnline()) {
                    overlay?.showPanel("OFFLINE", "অফলাইন বাংলা ভয়েস প্যাক নেই। অ্যাপে Offline voice pack বাটন চেপে বাংলা ডাউনলোড করো।")
                    listen(Mode.WAKE, 15000)
                    return
                }
            }
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                overlay?.showPanel("ERROR", "মাইক্রোফোন পারমিশন দাও।")
                return
            }
            if (mode == Mode.COMMAND) {
                overlay?.hidePanel()
                overlay?.setActive(false)
                listen(Mode.WAKE, 500)
            } else {
                val d = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 400L
                listen(Mode.WAKE, d)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (mode != Mode.WAKE || handled || busy) return
            val l = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (isWake(l)) {
                handled = true
                main.post { onWake() }
            }
        }

        override fun onResults(results: Bundle?) {
            if (!running || handled || busy) return
            val l = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            AppLog.add("heard[" + mode + "]: " + (l?.firstOrNull() ?: ""))
            if (mode == Mode.WAKE) {
                if (isWake(l)) {
                    handled = true
                    main.post { onWake() }
                } else {
                    listen(Mode.WAKE, 200)
                }
            } else {
                val text = l?.firstOrNull()?.trim() ?: ""
                if (text.isEmpty()) {
                    overlay?.hidePanel()
                    overlay?.setActive(false)
                    listen(Mode.WAKE, 300)
                } else {
                    handled = true
                    process(text)
                }
            }
        }
    }

    // ---------- Flow ----------
    private fun onOrbTapped() {
        if (busy) return
        releaseSr()
        handled = true
        onWake()
    }

    private fun onWake() {
        releaseSr()
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        } catch (e: Exception) { }
        overlay?.setActive(true)
        overlay?.showPanel("LISTENING", "বলো, আমি শুনছি...")
        listen(Mode.COMMAND, 450)
    }

    private fun process(text: String) {
        busy = true
        releaseSr()
        overlay?.showPanel("THINKING", "তুমি: $text")
        val app = applicationContext
        Thread {
            val reply = try {
                CommandRouter.handle(app, text) ?: if (app.isOnline()) Brain.ask(app, text) else OFFLINE_MSG
            } catch (e: Exception) {
                "একটা সমস্যা হয়েছে, আবার বলো।"
            }
            AppLog.add("cmd: $text -> $reply")
            main.post {
                overlay?.showPanel("NH-AI", reply)
                val followUp = reply.trim().endsWith("?")
                speak(reply) {
                    if (followUp) {
                        busy = false
                        overlay?.setActive(true)
                        listen(Mode.COMMAND, 300)
                    } else {
                        main.postDelayed({
                            overlay?.hidePanel()
                            overlay?.setActive(false)
                            busy = false
                            listen(Mode.WAKE, 200)
                        }, 3000)
                    }
                }
            }
        }.start()
    }

    private fun speak(text: String, done: () -> Unit) {
        val t = tts
        var fired = false
        val fire: () -> Unit = {
            if (!fired) {
                fired = true
                done()
            }
        }
        if (t == null || !ttsReady) {
            main.postDelayed({ fire() }, 2000)
            return
        }
        val bn = text.any { it in '\u0980'..'\u09FF' }
        t.setLanguage(if (bn) Locale("bn", "BD") else Locale.US)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { main.post { fire() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { main.post { fire() } }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nh")
        val maxWait = minOf(25000L, 4000L + text.length * 130L)
        main.postDelayed({ fire() }, maxWait)
    }

    override fun onDestroy() {
        running = false
        isRunning = false
        main.removeCallbacksAndMessages(null)
        releaseSr()
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        overlay?.removeAll()
        super.onDestroy()
    }
}
