package com.nhai.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.math.sin

class OrbView(ctx: Context) : View(ctx) {
    var active = false
    private var angle = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 4000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            angle = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!anim.isRunning) anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        if (r <= 0f) return
        val speed = if (active) 6.0 else 3.0
        val pulse = 1f + 0.07f * sin(Math.toRadians(angle * speed)).toFloat()
        val core = r * 0.5f * pulse
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, core,
            intArrayOf(Color.WHITE, if (active) C.MAG else C.CYAN, C.PURPLE, Color.TRANSPARENT),
            floatArrayOf(0f, 0.35f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, core, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = r * 0.05f
        paint.color = if (active) C.MAG else C.CYAN
        val r1 = r * 0.9f
        rect.set(cx - r1, cy - r1, cx + r1, cy + r1)
        c.drawArc(rect, angle, 100f, false, paint)
        c.drawArc(rect, angle + 180f, 100f, false, paint)
        paint.color = if (active) C.CYAN else C.MAG
        val r2 = r * 0.72f
        rect.set(cx - r2, cy - r2, cx + r2, cy + r2)
        c.drawArc(rect, -angle * 1.5f, 70f, false, paint)
        c.drawArc(rect, -angle * 1.5f + 180f, 70f, false, paint)
    }
}
