package com.nhai.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import org.json.JSONObject
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Phone-er command gulo ekhane handle hoy. null return korle Claude AI uttor dey. */
object CommandRouter {

    private const val ACC_MSG = "আগে Accessibility সার্ভিস চালু করো।"

    private val bnApps = mapOf(
        "ইউটিউব" to "youtube", "হোয়াটসঅ্যাপ" to "whatsapp",
        "ফেসবুক" to "facebook", "ক্যামেরা" to "camera", "গুগল" to "google",
        "ম্যাপ" to "maps", "মেসেঞ্জার" to "messenger", "সেটিং" to "settings",
        "ক্রোম" to "chrome", "গ্যালারি" to "gallery", "জিমেইল" to "gmail",
        "টেলিগ্রাম" to "telegram", "ইন্সটাগ্রাম" to "instagram", "টিকটক" to "tiktok",
        "ক্যালকুলেটর" to "calculator"
    )

    private fun has(t: String, vararg k: String): Boolean = k.any { t.contains(it) }

    private fun normDigits(s: String): String {
        val sb = StringBuilder()
        for (ch in s) sb.append(if (ch in '০'..'৯') '0' + (ch - '০') else ch)
        return sb.toString()
    }

    internal fun go(ctx: Context, i: Intent): Boolean {
        return try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun handle(ctx: Context, raw: String): String? {
        val t = normDigits(raw.lowercase(Locale.ROOT)).trim()
        if (t.isEmpty()) return null

        // --- Accessibility (phone control) ---
        if (Regex("^(click|tap|ক্লিক|ট্যাপ)\\s+(.+)$").find(t) != null) {
            val target = Regex("^(click|tap|ক্লিক|ট্যাপ)\\s+(.+)$").find(t)!!.groupValues[2].trim()
            val s = NhAccessibilityService.instance ?: return ACC_MSG
            return if (s.clickText(target)) "ক্লিক করলাম।" else "\"$target\" স্ক্রিনে পেলাম না।"
        }
        if (Regex("\\bhome\\b").containsMatchIn(t) || has(t, "হোম স্ক্রিন", "হোমে যাও")) {
            val s = NhAccessibilityService.instance ?: return ACC_MSG
            s.home(); return "হোমে গেলাম।"
        }
        if (Regex("\\bback\\b").containsMatchIn(t) || has(t, "পিছনে", "ফিরে যাও", "ব্যাক")) {
            val s = NhAccessibilityService.instance ?: return ACC_MSG
            s.back(); return "পিছনে গেলাম।"
        }
        if (has(t, "recent", "রিসেন্ট")) {
            val s = NhAccessibilityService.instance ?: return ACC_MSG
            s.recents(); return "রিসেন্ট অ্যাপ দেখাচ্ছি।"
        }
        if (has(t, "notification", "নোটিফিকেশন")) {
            val s = NhAccessibilityService.instance ?: return ACC_MSG
            s.notifications(); return "নোটিফিকেশন খুলছি।"
        }
        if (has(t, "scroll down", "নিচে নামো", "নিচে স্ক্রল", "scroll korao")) {
            val s = NhAccessibilityService.instance ?: return ACC_MSG
            return if (s.scroll(true)) "স্ক্রল করলাম।" else "স্ক্রল করার জায়গা পেলাম না।"
        }
        if (has(t, "scroll up", "উপরে উঠো", "উপরে স্ক্রল")) {
            val s = NhAccessibilityService.instance ?: return ACC_MSG
            return if (s.scroll(false)) "স্ক্রল করলাম।" else "স্ক্রল করার জায়গা পেলাম না।"
        }

        // --- Torch ---
        if (has(t, "torch", "flashlight", "flash light", "টর্চ", "ফ্ল্যাশ", "ফ্লাশ")) {
            val off = has(t, "off", "bondho", "বন্ধ", "নিভা", "নেভা")
            return torch(ctx, !off)
        }

        // --- Volume ---
        if (has(t, "volume", "ভলিউম", "আওয়াজ", "সাউন্ড")) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (has(t, "mute", "silent", "সাইলেন্ট", "মিউট", "নিঃশব্দ")) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                return "ভলিউম মিউট করলাম।"
            }
            if (has(t, "up", "barao", "increase", "বাড়া", "বেশি")) {
                repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
                return "ভলিউম বাড়ালাম।"
            }
            if (has(t, "down", "komao", "decrease", "কমা", "কম")) {
                repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
                return "ভলিউম কমালাম।"
            }
        }

        // --- Alarm ---
        if (has(t, "alarm", "অ্যালার্ম", "এলার্ম", "আলার্ম")) return alarm(ctx, t)

        // --- Battery / media / screenshot / lock (offline) ---
        if (has(t, "battery", "ব্যাটারি", "চার্জ কত")) {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            return "ব্যাটারি " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " শতাংশ।"
        }
        if (Regex("\\bnext (song|track)\\b").containsMatchIn(t) || has(t, "পরের গান", "পরেরটা দাও")) {
            Tools.run(ctx, "media", JSONObject().put("action", "next")); return "পরের গান দিচ্ছি।"
        }
        if (Regex("\\bprevious (song|track)\\b").containsMatchIn(t) || has(t, "আগের গান")) {
            Tools.run(ctx, "media", JSONObject().put("action", "previous")); return "আগের গান দিচ্ছি।"
        }
        if (has(t, "গান থামাও", "গান বন্ধ", "গান চালাও", "pause music", "stop music", "play music", "resume music")) {
            Tools.run(ctx, "media", JSONObject().put("action", "play_pause")); return "ঠিক আছে।"
        }
        if (has(t, "screenshot", "স্ক্রিনশট")) {
            val s = NhAccessibilityService.instance ?: return ACC_MSG
            return if (s.press("screenshot")) "স্ক্রিনশট নিলাম।" else "স্ক্রিনশট নিতে পারলাম না।"
        }
        if (Regex("\\block (the )?(screen|phone)\\b").containsMatchIn(t) || has(t, "স্ক্রিন লক", "ফোন লক")) {
            val s = NhAccessibilityService.instance ?: return ACC_MSG
            return if (s.press("lock")) "ফোন লক করলাম।" else "লক করতে পারলাম না।"
        }

        // --- Settings panels ---
        if (has(t, "wifi", "wi-fi", "ওয়াইফাই", "ওয়াই-ফাই")) {
            go(ctx, Intent(Settings.ACTION_WIFI_SETTINGS)); return "ওয়াই-ফাই সেটিংস খুলছি।"
        }
        if (has(t, "bluetooth", "ব্লুটুথ")) {
            go(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "ব্লুটুথ সেটিংস খুলছি।"
        }

        // --- Time ---
        if (has(t, "what time", "somoy", "সময়", "কয়টা", "কটা বাজে", "টাইম কত")) {
            val f = SimpleDateFormat("hh:mm a", Locale.getDefault())
            return "এখন সময় " + f.format(Date())
        }

        // --- Call ---
        if (Regex("\\bcall\\b").containsMatchIn(t) || has(t, "ফোন করো", "ফোন দাও", "কল করো", "কল দাও", "phone koro")) {
            return call(ctx, t)
        }

        // --- Open app ---
        val openWords = listOf("open ", "khulo", "kholo", "খুলো", "খোলো", "খুলে", "খুলুন", "খুল", "ওপেন", "চালু করে", "চালু করো", "চালু কর", "chalu koro", "start ")
        if (openWords.any { t.contains(it) }) {
            var name = t
            for (w in openWords) name = name.replace(w, " ")
            val stopW = setOf("koro", "করো", "কর", "দাও", "dao", "app", "অ্যাপ", "টা", "the")
            name = name.split(Regex("\\s+")).filter { it !in stopW }.joinToString(" ")
            for ((bn, en) in bnApps) name = name.replace(bn, en)
            name = name.trim().replace(Regex("\\s+"), " ")
            if (name.length < 2) return null
            return openApp(ctx, name)
        }
        return null
    }

    internal fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
        val best = apps.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.ROOT) == name }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(name) }
            ?: apps.firstOrNull {
                val l = it.loadLabel(pm).toString().lowercase(Locale.ROOT)
                l.length > 2 && name.contains(l)
            }
        if (best == null) return "\"$name\" নামে কোনো অ্যাপ পেলাম না।"
        val li = pm.getLaunchIntentForPackage(best.activityInfo.packageName) ?: return "অ্যাপটা খুলতে পারলাম না।"
        val label = best.loadLabel(pm).toString()
        return if (go(ctx, li)) "$label খুলছি।" else "অ্যাপটা খুলতে পারলাম না।"
    }

    internal fun torch(ctx: Context, on: Boolean): String {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var id: String? = null
            for (cid in cm.cameraIdList) {
                if (cm.getCameraCharacteristics(cid).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) {
                    id = cid
                    break
                }
            }
            if (id == null) return "এই ফোনে ফ্ল্যাশ পেলাম না।"
            cm.setTorchMode(id, on)
            return if (on) "টর্চ জ্বালালাম।" else "টর্চ বন্ধ করলাম।"
        } catch (e: Exception) {
            return "টর্চ চালাতে পারলাম না।"
        }
    }

    private fun alarm(ctx: Context, t: String): String {
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(t) ?: return "কয়টায় অ্যালার্ম দেব বলো, যেমন: সকাল ৬:৩০।"
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if (has(t, "pm", "রাত", "বিকাল", "বিকেল", "সন্ধ্যা", "দুপুর") && h < 12) h += 12
        if (h > 23 || min > 59) return "সময়টা বুঝতে পারলাম না।"
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "NH-Ai")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (go(ctx, i)) "অ্যালার্ম সেট করলাম।" else "অ্যালার্ম সেট করতে পারলাম না।"
    }

    private fun call(ctx: Context, t: String): String {
        val stop = setOf("call", "ফোন", "কল", "করো", "কর", "দাও", "koro", "dao", "phone", "to", "কে", "ke")
        val name = t.split(Regex("\\s+")).filter { it !in stop }.joinToString(" ").trim()
        if (name.isEmpty()) return "কাকে ফোন করব?"
        return dial(ctx, name)
    }

    /** Naam ba number theke phone number ber kore. Contacts permission lagbe. */
    internal fun lookupNumber(ctx: Context, name: String): String? {
        val digits = name.filter { it.isDigit() || it == '+' }
        if (digits.length >= 5) return digits
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        var number: String? = null
        try {
            val cur = ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%$name%"), null
            )
            if (cur != null) {
                try {
                    if (cur.moveToFirst()) number = cur.getString(0)
                } finally {
                    cur.close()
                }
            }
        } catch (e: Exception) { }
        return number
    }

    internal fun dial(ctx: Context, name: String): String {
        val n = lookupNumber(ctx, name) ?: return "\"$name\" নামে কোনো কন্টাক্ট পেলাম না, বা কন্টাক্ট পারমিশন নেই।"
        val direct = Prefs.directCall(ctx) &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val action = if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val ok = go(ctx, Intent(action, Uri.parse("tel:" + Uri.encode(n))))
        if (!ok) return "ফোন করতে পারলাম না।"
        return if (direct) "ফোন করছি।" else "ডায়ালার খুলেছি, কল বাটন চাপো।"
    }
}
