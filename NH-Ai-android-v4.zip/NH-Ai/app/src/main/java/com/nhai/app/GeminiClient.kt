package com.nhai.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Provider switch: Settings e Gemini (free) ba Claude. */
object Brain {
    fun ask(ctx: Context, text: String): String =
        if (Prefs.provider(ctx) == "gemini") GeminiClient.ask(ctx, text) else ClaudeClient.ask(ctx, text)
}

object GeminiClient {
    private val hist = ArrayList<Pair<String, String>>()

    // Claude-er tool definition ke Gemini-r functionDeclarations e convert kora hoy.
    private val decls: JSONArray by lazy {
        val out = JSONArray()
        val defs = Tools.defs
        for (i in 0 until defs.length()) {
            val d = defs.getJSONObject(i)
            val f = JSONObject().put("name", d.getString("name")).put("description", d.getString("description"))
            val schema = d.getJSONObject("input_schema")
            val props = schema.getJSONObject("properties")
            if (props.length() > 0) {
                val params = JSONObject().put("type", "object").put("properties", props)
                val req = schema.optJSONArray("required")
                if (req != null && req.length() > 0) params.put("required", req)
                f.put("parameters", params)
            }
            out.put(f)
        }
        out
    }

    private fun textMsg(role: String, text: String): JSONObject =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    @Synchronized
    fun ask(ctx: Context, text: String): String {
        val key = Prefs.geminiKey(ctx)
        if (key.isEmpty()) return "আগে অ্যাপে Gemini API key সেভ করো।"
        val contents = JSONArray()
        for (m in hist) contents.put(textMsg(m.first, m.second))
        contents.put(textMsg("user", text))
        try {
            for (step in 0 until 7) {
                val resp = post(ctx, key, contents)
                val cands = resp.optJSONArray("candidates")
                if (cands == null || cands.length() == 0) {
                    AppLog.add("gemini no candidates: " + resp.toString().take(200))
                    return "এই প্রশ্নের উত্তর পেলাম না, অন্যভাবে বলো।"
                }
                val content = cands.getJSONObject(0).optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (content == null || parts == null) return "উত্তর খালি এসেছে, আবার বলো।"
                if (!content.has("role")) content.put("role", "model")
                val calls = ArrayList<JSONObject>()
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    val fc = p.optJSONObject("functionCall")
                    if (fc != null) {
                        calls.add(fc)
                    } else if (p.has("text") && !p.optBoolean("thought", false)) {
                        sb.append(p.optString("text"))
                    }
                }
                if (calls.isEmpty()) {
                    val out = sb.toString().trim().ifEmpty { "হয়ে গেছে।" }
                    remember(text, out)
                    return out
                }
                contents.put(content)
                val respParts = JSONArray()
                for (fc in calls) {
                    val name = fc.getString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    val out = Tools.run(ctx, name, args)
                    respParts.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().put("name", name).put("response", JSONObject().put("result", out.ifEmpty { "ok" }))
                        )
                    )
                }
                contents.put(JSONObject().put("role", "user").put("parts", respParts))
            }
            return "কাজটা শেষ করতে পারলাম না, আবার চেষ্টা করো।"
        } catch (e: ApiException) {
            AppLog.add("gemini: " + e.message)
            return e.message ?: "Gemini error"
        } catch (e: Exception) {
            AppLog.add("gemini net: " + e)
            return "ইন্টারনেট বা Gemini তে সমস্যা হচ্ছে।"
        }
    }

    private fun remember(user: String, model: String) {
        hist.add(Pair("user", user))
        hist.add(Pair("model", model))
        while (hist.size > 12) hist.removeAt(0)
        while (hist.isNotEmpty() && hist[0].first != "user") hist.removeAt(0)
    }

    private fun post(ctx: Context, key: String, contents: JSONArray): JSONObject {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", ClaudeClient.system()))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", decls)))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 1024))
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" + Prefs.geminiModel(ctx) + ":generateContent"
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                if (code == 429) throw ApiException("Gemini-র ফ্রি লিমিট এখন শেষ, একটু পরে আবার বলো।")
                if (code == 404) throw ApiException("Model নামটা ভুল মনে হচ্ছে, Settings এ Gemini model ঠিক করো।")
                if (code == 400 && resp.contains("API key", ignoreCase = true)) throw ApiException("Gemini API key ভুল মনে হচ্ছে।")
                if (code == 403) throw ApiException("Gemini key কাজ করছে না (403)। নতুন key বানাও।")
                throw ApiException("Gemini error $code: " + resp.take(140))
            }
            return JSONObject(resp)
        } finally {
            c.disconnect()
        }
    }
}
