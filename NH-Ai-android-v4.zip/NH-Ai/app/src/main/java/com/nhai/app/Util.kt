package com.nhai.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

object C {
    val BG = Color.parseColor("#05060F")
    val CYAN = Color.parseColor("#00F0FF")
    val MAG = Color.parseColor("#FF2BD6")
    val PURPLE = Color.parseColor("#8A5CFF")
    val TEXT = Color.parseColor("#D8F6FF")
    val DIM = Color.parseColor("#6F8AA0")
    val CARD = Color.parseColor("#0B0F24")
    val PANEL = Color.parseColor("#EE070A1C")
}

fun neonBg(ctx: Context, stroke: Int, fill: Int = C.CARD, radius: Int = 14): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(fill)
    d.cornerRadius = ctx.dp(radius).toFloat()
    d.setStroke(ctx.dp(2), stroke)
    return d
}

const val OFFLINE_MSG =
    "এখন ইন্টারনেট নেই, তাই এই প্রশ্নের উত্তর দিতে পারছি না। অ্যাপ খোলা, কল, টর্চ, ভলিউম, অ্যালার্ম, স্ক্রিন কন্ট্রোল এগুলো অফলাইনেও করতে পারি।"

fun Context.isOnline(): Boolean {
    return try {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val c = if (n != null) cm.getNetworkCapabilities(n) else null
        c != null &&
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (e: Exception) {
        true
    }
}
