package com.nhai.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** App-er bhitore debug log: recognizer ki shunlo, kon tool chollo, error ki. */
object AppLog {
    private val lines = ArrayList<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun add(s: String) {
        lines.add(fmt.format(Date()) + " " + s.take(300))
        while (lines.size > 60) lines.removeAt(0)
    }

    @Synchronized
    fun dump(): String = if (lines.isEmpty()) "(log খালি)" else lines.joinToString("\n")

    @Synchronized
    fun clear() {
        lines.clear()
    }
}
