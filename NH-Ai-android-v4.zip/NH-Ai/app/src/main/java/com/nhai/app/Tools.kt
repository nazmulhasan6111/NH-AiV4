package com.nhai.app

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Claude ei tool gulo diye phone chalay. */
object Tools {
    private const val ACC_OFF =
        "Accessibility service is OFF. Tell the user to enable NH-Ai in Accessibility (step 3 in the app)."

    private fun str(d: String) = JSONObject().put("type", "string").put("description", d)
    private fun int(d: String) = JSONObject().put("type", "integer").put("description", d)
    private fun bool(d: String) = JSONObject().put("type", "boolean").put("description", d)

    private fun p(vararg kv: Pair<String, JSONObject>): JSONObject {
        val o = JSONObject()
        for (e in kv) o.put(e.first, e.second)
        return o
    }

    private fun tool(name: String, desc: String, props: JSONObject, vararg req: String): JSONObject {
        val schema = JSONObject()
            .put("type", "object")
            .put("properties", props)
            .put("required", JSONArray(req.toList()))
        return JSONObject().put("name", name).put("description", desc).put("input_schema", schema)
    }

    val defs: JSONArray by lazy {
        val a = JSONArray()
        a.put(tool("open_app", "Open an installed app by its name (e.g. YouTube, WhatsApp, Camera, Settings).", p("name" to str("App name")), "name"))
        a.put(tool("call", "Call a contact by name or a phone number. Opens the dialer unless direct calling is enabled.", p("target" to str("Contact name or phone number")), "target"))
        a.put(tool("send_sms", "Open the SMS app with a prefilled message. The user must press send.", p("to" to str("Contact name or number"), "message" to str("Message text")), "to", "message"))
        a.put(tool("send_whatsapp", "Open a WhatsApp chat with a prefilled message. The user must press send.", p("to" to str("Contact name or number"), "message" to str("Message text")), "to", "message"))
        a.put(tool("read_screen", "Read the visible text on the current phone screen. Use it to see what is on screen.", JSONObject()))
        a.put(tool("click", "Tap a button or item on the current screen by its visible text.", p("text" to str("Visible text or description of the element")), "text"))
        a.put(tool("type_text", "Type text into the currently focused input field (replaces its content).", p("text" to str("Text to type")), "text"))
        a.put(tool("scroll", "Scroll the current screen.", p("direction" to str("down or up")), "direction"))
        a.put(tool("press", "Press a system button.", p("key" to str("home, back, recents, notifications, lock, screenshot or power")), "key"))
        a.put(tool("set_alarm", "Set an alarm at a time of day (24-hour clock).", p("hour" to int("0-23"), "minute" to int("0-59")), "hour", "minute"))
        a.put(tool("set_timer", "Start a countdown timer.", p("seconds" to int("Duration in seconds")), "seconds"))
        a.put(tool("torch", "Turn the flashlight on or off.", p("on" to bool("true for on, false for off")), "on"))
        a.put(tool("set_volume", "Change media volume.", p("action" to str("up, down, mute or max")), "action"))
        a.put(tool("media", "Control music/video playback.", p("action" to str("play_pause, next, previous or stop")), "action"))
        a.put(tool("open_url", "Open a web address in the browser.", p("url" to str("URL")), "url"))
        a.put(tool("web_search", "Search Google for something.", p("query" to str("Search query")), "query"))
        a.put(tool("youtube_search", "Search YouTube for something.", p("query" to str("Search query")), "query"))
        a.put(tool("navigate", "Show a place on the map / start navigation.", p("place" to str("Place name or address")), "place"))
        a.put(tool("open_settings", "Open a phone settings page.", p("page" to str("wifi, bluetooth, location, airplane, display, sound, battery or main")), "page"))
        a.put(tool("battery", "Get the battery level and charging state.", JSONObject()))
        a.put(tool("current_time", "Get the current date and time.", JSONObject()))
        a.put(tool("wait", "Wait a few seconds, e.g. after opening an app before reading the screen.", p("seconds" to int("1 to 5")), "seconds"))
        a
    }

    fun run(ctx: Context, name: String, a: JSONObject): String {
        AppLog.add("tool $name $a")
        val r = try {
            exec(ctx, name, a)
        } catch (e: Exception) {
            "error: " + e.message
        }
        AppLog.add("  -> " + r.take(120))
        return r
    }

    private fun waNumber(ctx: Context, raw: String): String {
        val plus = raw.trim().startsWith("+")
        val d = raw.filter { it.isDigit() }
        if (plus) return d
        if (d.startsWith("00")) return d.substring(2)
        if (d.startsWith("0")) return Prefs.countryCode(ctx) + d.substring(1)
        return d
    }

    private fun exec(ctx: Context, name: String, a: JSONObject): String {
        val acc = NhAccessibilityService.instance
        when (name) {
            "open_app" -> return CommandRouter.openApp(ctx, a.optString("name").lowercase(Locale.ROOT).trim())
            "call" -> return CommandRouter.dial(ctx, a.optString("target").trim())
            "send_sms" -> {
                val to = a.optString("to").trim()
                val n = CommandRouter.lookupNumber(ctx, to) ?: return "No number found for '$to' (contacts permission or name)."
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n)))
                i.putExtra("sms_body", a.optString("message"))
                return if (CommandRouter.go(ctx, i)) "SMS app opened with the message prefilled. The user must press send." else "Could not open the SMS app."
            }
            "send_whatsapp" -> {
                val to = a.optString("to").trim()
                val raw = CommandRouter.lookupNumber(ctx, to) ?: return "No number found for '$to' (contacts permission or name)."
                val uri = Uri.parse("https://wa.me/" + waNumber(ctx, raw) + "?text=" + Uri.encode(a.optString("message")))
                return if (CommandRouter.go(ctx, Intent(Intent.ACTION_VIEW, uri))) "WhatsApp opened with the message prefilled. The user must press send." else "Could not open WhatsApp."
            }
            "read_screen" -> return acc?.readScreen() ?: ACC_OFF
            "click" -> {
                if (acc == null) return ACC_OFF
                val t = a.optString("text")
                return if (acc.clickText(t)) "Clicked '$t'." else "No clickable element with text '$t' found on screen."
            }
            "type_text" -> {
                if (acc == null) return ACC_OFF
                return if (acc.typeText(a.optString("text"))) "Typed." else "No focused input field. Click the field first."
            }
            "scroll" -> {
                if (acc == null) return ACC_OFF
                val down = a.optString("direction").lowercase(Locale.ROOT) != "up"
                return if (acc.scroll(down)) "Scrolled." else "Nothing scrollable found."
            }
            "press" -> {
                if (acc == null) return ACC_OFF
                return if (acc.press(a.optString("key").lowercase(Locale.ROOT))) "Done." else "Could not press that key."
            }
            "set_alarm" -> {
                val h = a.optInt("hour", -1)
                val m = a.optInt("minute", 0)
                if (h !in 0..23 || m !in 0..59) return "Invalid time."
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h)
                    .putExtra(AlarmClock.EXTRA_MINUTES, m)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "NH-Ai")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                return if (CommandRouter.go(ctx, i)) "Alarm set for %02d:%02d.".format(h, m) else "Could not set the alarm."
            }
            "set_timer" -> {
                val s = a.optInt("seconds", 0)
                if (s <= 0) return "Invalid duration."
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, s)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "NH-Ai")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                return if (CommandRouter.go(ctx, i)) "Timer started for $s seconds." else "Could not start the timer."
            }
            "torch" -> return CommandRouter.torch(ctx, a.optBoolean("on", true))
            "set_volume" -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val s = AudioManager.STREAM_MUSIC
                when (a.optString("action").lowercase(Locale.ROOT)) {
                    "up" -> repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
                    "down" -> repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
                    "mute" -> am.setStreamVolume(s, 0, AudioManager.FLAG_SHOW_UI)
                    "max" -> am.setStreamVolume(s, am.getStreamMaxVolume(s), AudioManager.FLAG_SHOW_UI)
                    else -> return "Unknown volume action."
                }
                return "Volume changed."
            }
            "media" -> {
                val code = when (a.optString("action").lowercase(Locale.ROOT)) {
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
                    else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                }
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
                return "Media key sent."
            }
            "open_url" -> {
                var u = a.optString("url").trim()
                if (!u.contains("://")) u = "https://$u"
                return if (CommandRouter.go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) "Opened $u" else "Could not open the link."
            }
            "web_search" -> {
                val u = "https://www.google.com/search?q=" + Uri.encode(a.optString("query"))
                return if (CommandRouter.go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) "Search opened." else "Could not open the browser."
            }
            "youtube_search" -> {
                val u = "https://www.youtube.com/results?search_query=" + Uri.encode(a.optString("query"))
                return if (CommandRouter.go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) "YouTube search opened." else "Could not open YouTube."
            }
            "navigate" -> {
                val u = "geo:0,0?q=" + Uri.encode(a.optString("place"))
                return if (CommandRouter.go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) "Map opened." else "No map app found."
            }
            "open_settings" -> {
                val act = when (a.optString("page").lowercase(Locale.ROOT)) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                    "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                    "display" -> Settings.ACTION_DISPLAY_SETTINGS
                    "sound" -> Settings.ACTION_SOUND_SETTINGS
                    "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                    else -> Settings.ACTION_SETTINGS
                }
                return if (CommandRouter.go(ctx, Intent(act))) "Settings opened." else "Could not open settings."
            }
            "battery" -> {
                val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                return "Battery $lvl%, " + (if (bm.isCharging) "charging" else "not charging")
            }
            "current_time" -> return SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
            "wait" -> {
                val s = a.optInt("seconds", 2).coerceIn(1, 5)
                Thread.sleep(s * 1000L)
                return "Waited $s seconds."
            }
        }
        return "Unknown tool: $name"
    }
}
